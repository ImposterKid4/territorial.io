using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TerritorialHQ_APIS.Pages.Authentication
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
