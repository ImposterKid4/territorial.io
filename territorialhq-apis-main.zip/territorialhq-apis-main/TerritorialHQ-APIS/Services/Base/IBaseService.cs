﻿namespace TerritorialHQ_APIS.Services.Base
{
    public interface IBaseService
    {
    }
}
