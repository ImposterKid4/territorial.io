﻿namespace TerritorialHQ.Services.Base
{
    public interface IBaseService
    {
    }
}
