﻿namespace TerritorialHQ.Models.Cache
{
    public class DiscordCacheModel
    {
        public string? Username { get; set; }
        public string? Avatar { get; set; }
    }
}
