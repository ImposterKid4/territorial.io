﻿namespace TerritorialHQ.ViewModels
{
    public class LeaderboardEntry
    {
        public int Rank { get; set; }
        public string? Name { get; set; }
        public decimal Points { get; set; }
    }
}
