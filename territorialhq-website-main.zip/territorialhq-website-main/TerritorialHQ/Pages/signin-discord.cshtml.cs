using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace TerritorialHQ.Pages
{
    public class signin_discordModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
